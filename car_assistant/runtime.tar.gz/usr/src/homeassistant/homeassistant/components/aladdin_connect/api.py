"""API for Aladdin Connect Genie bound to Home Assistant OAuth."""

from typing import cast, override

from aiohttp import ClientSession
from genie_partner_sdk.auth import Auth

from homeassistant.helpers import config_entry_oauth2_flow

API_URL = "https://twdvzuefzh.execute-api.us-east-2.amazonaws.com/v1"
API_KEY = "k6QaiQmcTm2zfaNns5L1Z8duBtJmhDOW8JawlCC3"


class AsyncConfigFlowAuth(Auth):
    """Provide Aladdin Connect Genie authentication for config flow validation."""

    def __init__(self, websession: ClientSession, access_token: str) -> None:
        """Initialize Aladdin Connect Genie auth."""
        super().__init__(websession, API_URL, access_token, API_KEY)

    @override
    async def async_get_access_token(self) -> str:
        """Return the access token."""
        return self.access_token


class AsyncConfigEntryAuth(Auth):
    """Provide Aladdin Connect Genie auth tied to an OAuth2 config entry."""

    def __init__(
        self,
        websession: ClientSession,
        oauth_session: config_entry_oauth2_flow.OAuth2Session,
    ) -> None:
        """Initialize Aladdin Connect Genie auth."""
        super().__init__(
            websession, API_URL, oauth_session.token["access_token"], API_KEY
        )
        self._oauth_session = oauth_session

    @override
    async def async_get_access_token(self) -> str:
        """Return a valid access token."""
        await self._oauth_session.async_ensure_token_valid()

        return cast(str, self._oauth_session.token["access_token"])
