"""Virtual integration: Acomax."""
