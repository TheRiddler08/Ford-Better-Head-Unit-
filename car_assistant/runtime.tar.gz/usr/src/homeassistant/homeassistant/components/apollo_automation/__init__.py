"""Virtual integration: Apollo Automation."""
