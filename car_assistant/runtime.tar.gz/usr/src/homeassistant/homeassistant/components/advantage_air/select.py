"""Select platform for Advantage Air integration."""

from typing import override

from homeassistant.components.select import SelectEntity
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from . import AdvantageAirDataConfigEntry
from .coordinator import AdvantageAirCoordinator
from .entity import AdvantageAirAcEntity

ADVANTAGE_AIR_INACTIVE = "Inactive"


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: AdvantageAirDataConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up AdvantageAir select platform."""

    coordinator = config_entry.runtime_data

    if aircons := coordinator.data.get("aircons"):
        async_add_entities(
            AdvantageAirMyZone(coordinator, ac_key) for ac_key in aircons
        )


class AdvantageAirMyZone(AdvantageAirAcEntity, SelectEntity):
    """Representation of Advantage Air MyZone control."""

    _attr_icon = "mdi:home-thermometer"
    _attr_name = "MyZone"

    def __init__(self, coordinator: AdvantageAirCoordinator, ac_key: str) -> None:
        """Initialize an Advantage Air MyZone control."""
        super().__init__(coordinator, ac_key)
        self._attr_unique_id += "-myzone"
        self._attr_options = [ADVANTAGE_AIR_INACTIVE]
        self._number_to_name = {0: ADVANTAGE_AIR_INACTIVE}
        self._name_to_number = {ADVANTAGE_AIR_INACTIVE: 0}

        if "aircons" in coordinator.data:
            for zone in coordinator.data["aircons"][ac_key]["zones"].values():
                if zone["type"] > 0:
                    self._name_to_number[zone["name"]] = zone["number"]
                    self._number_to_name[zone["number"]] = zone["name"]
                    self._attr_options.append(zone["name"])

    @property
    @override
    def current_option(self) -> str:
        """Return the current MyZone."""
        return self._number_to_name[self._ac["myZone"]]

    @override
    async def async_select_option(self, option: str) -> None:
        """Set the MyZone."""
        await self.async_update_ac({"myZone": self._name_to_number[option]})
