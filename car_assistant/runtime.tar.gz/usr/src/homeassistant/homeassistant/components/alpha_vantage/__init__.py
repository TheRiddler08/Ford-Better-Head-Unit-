"""The Alpha Vantage component."""
