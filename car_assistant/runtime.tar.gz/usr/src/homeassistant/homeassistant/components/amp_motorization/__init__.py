"""Virtual integration: AMP motorization."""
