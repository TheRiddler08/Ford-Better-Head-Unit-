"""The apprise component."""
