"""Support for notification entity."""

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Final, override

from aioamazondevices.api import AmazonEchoApi
from aioamazondevices.const.devices import SPEAKER_GROUP_FAMILY
from aioamazondevices.structures import AmazonDevice

from homeassistant.components.notify import NotifyEntity, NotifyEntityDescription
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .coordinator import AmazonConfigEntry, alexa_api_call
from .entity import AmazonEntity

PARALLEL_UPDATES = 1


@dataclass(frozen=True, kw_only=True)
class AmazonNotifyEntityDescription(NotifyEntityDescription):
    """Alexa Devices notify entity description."""

    is_supported_fn: Callable[[AmazonDevice], bool] = lambda _device: True
    is_available_fn: Callable[[AmazonDevice], bool] = lambda _device: True
    method: Callable[[AmazonEchoApi, AmazonDevice, str], Awaitable[None]]
    subkey: str


NOTIFY: Final = (
    AmazonNotifyEntityDescription(
        key="speak",
        translation_key="speak",
        subkey="AUDIO_PLAYER",
        is_supported_fn=lambda _device: _device.device_family != SPEAKER_GROUP_FAMILY,
        method=lambda api, device, message: api.call_alexa_speak(device, message),
    ),
    AmazonNotifyEntityDescription(
        key="announce",
        translation_key="announce",
        subkey="AUDIO_PLAYER",
        is_available_fn=lambda device: (
            device.communication_settings.get("communications") != "OFF"
        ),
        method=lambda api, device, message: api.call_alexa_announcement(
            device, message
        ),
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: AmazonConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up Alexa Devices notification entity based on a config entry."""

    coordinator = entry.runtime_data

    known_devices: set[str] = set()

    def _check_device() -> None:
        current_devices = set(coordinator.data)
        known_devices.intersection_update(current_devices)
        new_devices = current_devices - known_devices
        if new_devices:
            known_devices.update(new_devices)
            async_add_entities(
                AmazonNotifyEntity(coordinator, serial_num, sensor_desc)
                for sensor_desc in NOTIFY
                for serial_num in new_devices
                if sensor_desc.subkey in coordinator.data[serial_num].capabilities
                and sensor_desc.is_supported_fn(coordinator.data[serial_num])
            )

    _check_device()
    entry.async_on_unload(coordinator.async_add_listener(_check_device))


class AmazonNotifyEntity(AmazonEntity, NotifyEntity):
    """Binary sensor notify platform."""

    entity_description: AmazonNotifyEntityDescription

    @property
    @override
    def available(self) -> bool:
        """Return if entity is available."""
        return (
            self.entity_description.is_available_fn(self.device) and super().available
        )

    @override
    async def async_send_message(
        self, message: str, title: str | None = None, **kwargs: Any
    ) -> None:
        """Send a message."""
        async with alexa_api_call(self.coordinator):
            await self.entity_description.method(
                self.coordinator.api, self.device, message
            )
