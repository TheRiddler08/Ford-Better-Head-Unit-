"""The Airthings BLE integration."""

from datetime import timedelta
import logging
from typing import override

from airthings_ble import AirthingsBluetoothDeviceData, AirthingsDevice
from bleak.backends.device import BLEDevice
from bleak_retry_connector import close_stale_connections_by_address

from homeassistant.components import bluetooth
from homeassistant.components.bluetooth import BluetoothReachabilityIntent
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryNotReady
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import (
    DEFAULT_SCAN_INTERVAL,
    DEVICE_MODEL,
    DEVICE_SPECIFIC_SCAN_INTERVAL,
    DOMAIN,
)

_LOGGER = logging.getLogger(__name__)

type AirthingsBLEConfigEntry = ConfigEntry[AirthingsBLEDataUpdateCoordinator]


class AirthingsBLEDataUpdateCoordinator(DataUpdateCoordinator[AirthingsDevice]):
    """Class to manage fetching Airthings BLE data."""

    ble_device: BLEDevice
    config_entry: AirthingsBLEConfigEntry

    def __init__(self, hass: HomeAssistant, entry: AirthingsBLEConfigEntry) -> None:
        """Initialize the coordinator."""
        self.airthings = AirthingsBluetoothDeviceData(_LOGGER, is_metric=True)

        device_model = entry.data.get(DEVICE_MODEL)
        interval = DEVICE_SPECIFIC_SCAN_INTERVAL.get(
            device_model, DEFAULT_SCAN_INTERVAL
        )

        super().__init__(
            hass,
            _LOGGER,
            config_entry=entry,
            name=DOMAIN,
            update_interval=timedelta(seconds=interval),
        )

    @override
    async def _async_setup(self) -> None:
        """Set up the coordinator."""
        address = self.config_entry.unique_id

        assert address is not None

        await close_stale_connections_by_address(address)

        ble_device = bluetooth.async_ble_device_from_address(self.hass, address)

        if not ble_device:
            raise ConfigEntryNotReady(
                translation_domain=DOMAIN,
                translation_key="device_not_found",
                translation_placeholders={
                    "address": address,
                    "reason": bluetooth.async_address_reachability_diagnostics(
                        self.hass,
                        address.upper(),
                        BluetoothReachabilityIntent.CONNECTION,
                    ),
                },
            )
        self.ble_device = ble_device

        if DEVICE_MODEL not in self.config_entry.data:
            _LOGGER.debug("Fetching device info for migration")
            try:
                data = await self.airthings.update_device(self.ble_device)
            except Exception as err:
                raise UpdateFailed(
                    f"Unable to fetch data for migration: {err}"
                ) from err

            self.hass.config_entries.async_update_entry(
                self.config_entry,
                data={**self.config_entry.data, DEVICE_MODEL: data.model.value},
            )
            self.update_interval = timedelta(
                seconds=DEVICE_SPECIFIC_SCAN_INTERVAL.get(
                    data.model.value, DEFAULT_SCAN_INTERVAL
                )
            )

    @override
    async def _async_update_data(self) -> AirthingsDevice:
        """Get data from Airthings BLE."""
        try:
            data = await self.airthings.update_device(self.ble_device)
        except Exception as err:
            raise UpdateFailed(f"Unable to fetch data: {err}") from err

        if not data.address:
            # The device did not report its address, which means the read did not
            # complete. Building entities from this would create a duplicate device
            # and entities with an empty unique id prefix.
            raise UpdateFailed(
                translation_domain=DOMAIN,
                translation_key="incomplete_read",
            )

        device_registry = dr.async_get(self.hass)
        if (
            device := device_registry.async_get_device_by_connection(
                (dr.CONNECTION_BLUETOOTH, data.address), self.config_entry.entry_id
            )
        ) and device.sw_version != data.sw_version:
            device_registry.async_update_device(device.id, sw_version=data.sw_version)

        return data
