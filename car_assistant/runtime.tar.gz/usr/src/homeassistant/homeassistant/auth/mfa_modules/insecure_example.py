"""Example auth module."""

from typing import Any, override

import probatio

from homeassistant.core import HomeAssistant

from . import (
    MULTI_FACTOR_AUTH_MODULE_SCHEMA,
    MULTI_FACTOR_AUTH_MODULES,
    MultiFactorAuthModule,
    SetupFlow,
)

CONFIG_SCHEMA = MULTI_FACTOR_AUTH_MODULE_SCHEMA.extend(
    {
        probatio.Required("data"): [
            probatio.Schema(
                {probatio.Required("user_id"): str, probatio.Required("pin"): str}
            )
        ]
    },
    extra=probatio.PREVENT_EXTRA,
)


@MULTI_FACTOR_AUTH_MODULES.register("insecure_example")
class InsecureExampleModule(MultiFactorAuthModule):
    """Example auth module validate pin."""

    DEFAULT_TITLE = "Insecure Personal Identify Number"

    def __init__(self, hass: HomeAssistant, config: dict[str, Any]) -> None:
        """Initialize the user data store."""
        super().__init__(hass, config)
        self._data = config["data"]

    @property
    @override
    def input_schema(self) -> probatio.Schema:
        """Validate login flow input data."""
        return probatio.Schema({probatio.Required("pin"): str})

    @property
    def setup_schema(self) -> probatio.Schema:
        """Validate async_setup_user input data."""
        return probatio.Schema({probatio.Required("pin"): str})

    @override
    async def async_setup_flow(self, user_id: str) -> SetupFlow:
        """Return a data entry flow handler for setup module.

        Mfa module should extend SetupFlow
        """
        return SetupFlow(self, self.setup_schema, user_id)

    @override
    async def async_setup_user(self, user_id: str, setup_data: Any) -> Any:
        """Set up user to use mfa module."""
        # data shall has been validate in caller
        pin = setup_data["pin"]

        for data in self._data:
            if data["user_id"] == user_id:
                # already setup, override
                data["pin"] = pin
                return

        self._data.append({"user_id": user_id, "pin": pin})

    @override
    async def async_depose_user(self, user_id: str) -> None:
        """Remove user from mfa module."""
        found = None
        for data in self._data:
            if data["user_id"] == user_id:
                found = data
                break
        if found:
            self._data.remove(found)

    @override
    async def async_is_user_setup(self, user_id: str) -> bool:
        """Return whether user is setup."""
        return any(data["user_id"] == user_id for data in self._data)

    @override
    async def async_validate(self, user_id: str, user_input: dict[str, Any]) -> bool:
        """Return True if validation passed."""
        return any(
            data["user_id"] == user_id and data["pin"] == user_input["pin"]
            for data in self._data
        )
