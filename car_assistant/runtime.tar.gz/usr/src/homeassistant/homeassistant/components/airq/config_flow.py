"""Config flow for air-Q integration."""

import logging
from typing import Any, override

from aioairq import AirQ, InvalidAuth
from aiohttp.client_exceptions import ClientConnectionError
import probatio

from homeassistant.config_entries import ConfigEntry, ConfigFlow, ConfigFlowResult
from homeassistant.const import CONF_IP_ADDRESS, CONF_PASSWORD
from homeassistant.core import callback
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.schema_config_entry_flow import (
    SchemaFlowFormStep,
    SchemaOptionsFlowHandler,
)
from homeassistant.helpers.selector import BooleanSelector
from homeassistant.helpers.service_info.zeroconf import (
    ATTR_PROPERTIES_ID,
    ZeroconfServiceInfo,
)

from .const import CONF_CLIP_NEGATIVE, CONF_RETURN_AVERAGE, DOMAIN

_LOGGER = logging.getLogger(__name__)

STEP_USER_DATA_SCHEMA = probatio.Schema(
    {
        probatio.Required(CONF_IP_ADDRESS): str,
        probatio.Required(CONF_PASSWORD): str,
    }
)
OPTIONS_FLOW = {
    "init": SchemaFlowFormStep(
        schema=probatio.Schema(
            {
                probatio.Optional(CONF_RETURN_AVERAGE, default=True): BooleanSelector(),
                probatio.Optional(CONF_CLIP_NEGATIVE, default=True): BooleanSelector(),
            }
        )
    ),
}


class AirQConfigFlow(ConfigFlow, domain=DOMAIN):
    """Handle a config flow for air-Q."""

    VERSION = 1

    _discovered_host: str
    _discovered_name: str

    @override
    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Handle the initial (authentication) configuration step."""
        if user_input is None:
            return self.async_show_form(
                step_id="user", data_schema=STEP_USER_DATA_SCHEMA
            )

        errors: dict[str, str] = {}

        session = async_get_clientsession(self.hass)
        airq = AirQ(user_input[CONF_IP_ADDRESS], user_input[CONF_PASSWORD], session)
        try:
            await airq.validate()
        except ClientConnectionError:
            _LOGGER.debug(
                (
                    "Failed to connect to device %s. Check the IP address / device"
                    " ID as well as whether the device is connected to power and"
                    " the WiFi"
                ),
                user_input[CONF_IP_ADDRESS],
            )
            errors["base"] = "cannot_connect"
        except InvalidAuth:
            _LOGGER.debug(
                "Incorrect password for device %s", user_input[CONF_IP_ADDRESS]
            )
            errors["base"] = "invalid_auth"
        else:
            _LOGGER.debug("Successfully connected to %s", user_input[CONF_IP_ADDRESS])

            device_info = await airq.fetch_device_info()
            await self.async_set_unique_id(device_info["id"], raise_on_progress=False)
            self._abort_if_unique_id_configured()

            _LOGGER.debug("Creating an entry for %s", device_info["name"])
            return self.async_create_entry(title=device_info["name"], data=user_input)

        return self.async_show_form(
            step_id="user", data_schema=STEP_USER_DATA_SCHEMA, errors=errors
        )

    @override
    async def async_step_zeroconf(
        self, discovery_info: ZeroconfServiceInfo
    ) -> ConfigFlowResult:
        """Handle zeroconf discovery of an air-Q device."""
        self._discovered_host = discovery_info.host
        self._discovered_name = discovery_info.properties.get("devicename", "air-Q")
        device_id = discovery_info.properties.get(ATTR_PROPERTIES_ID)

        if not device_id:
            return self.async_abort(reason="incomplete_discovery")

        await self.async_set_unique_id(device_id)
        self._abort_if_unique_id_configured(
            updates={CONF_IP_ADDRESS: self._discovered_host},
            reload_on_update=True,
        )

        self.context["title_placeholders"] = {"name": self._discovered_name}

        return await self.async_step_discovery_confirm()

    async def async_step_discovery_confirm(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Handle user confirmation of a discovered air-Q device."""
        errors: dict[str, str] = {}

        if user_input is not None:
            session = async_get_clientsession(self.hass)
            airq = AirQ(self._discovered_host, user_input[CONF_PASSWORD], session)
            try:
                await airq.validate()
            except ClientConnectionError:
                errors["base"] = "cannot_connect"
            except InvalidAuth:
                errors["base"] = "invalid_auth"
            else:
                return self.async_create_entry(
                    title=self._discovered_name,
                    data={
                        CONF_IP_ADDRESS: self._discovered_host,
                        CONF_PASSWORD: user_input[CONF_PASSWORD],
                    },
                )

        return self.async_show_form(
            step_id="discovery_confirm",
            data_schema=probatio.Schema({probatio.Required(CONF_PASSWORD): str}),
            description_placeholders={"name": self._discovered_name},
            errors=errors,
        )

    @staticmethod
    @callback
    @override
    def async_get_options_flow(
        config_entry: ConfigEntry,
    ) -> SchemaOptionsFlowHandler:
        """Return the options flow."""
        return SchemaOptionsFlowHandler(config_entry, OPTIONS_FLOW)
